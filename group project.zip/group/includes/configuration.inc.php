<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = __DIR__;
  
  $htmlPath = "$dir/html";
  $bootstrapPath = "$dir/bootstrap";
  $navigationPath = "$dir/navigation";
  
  $meta = "$htmlPath/meta.inc.php";
  $footer = "$htmlPath/footer.inc.php";
  $bootstrapScript = "$bootstrapPath/bootstrap-script.inc.php";
  $bootstrapOptional = "$bootstrapPath/bootstrap-optional.inc.php";
  $navigation = "$navigationPath/navigation.inc.php";