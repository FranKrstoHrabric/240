<link rel="shortcut icon" href="./media/images/logosmall.png">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />

<!-- Javascript -->
<script src="./script/script.js" defer></script>
<script src="https://kit.fontawesome.com/1ff2b5277e.js" crossorigin="anonymous">
</script>