(function () {

    function init() { }

    let landing = document.getElementById('carousel');
    let nav = document.querySelector('nav');
    window.onscroll = function () {
        if (landing != null) {
            if (window.pageYOffset > landing.clientHeight) {
                nav.style.backgroundColor = '#f76902';
            } else {
                nav.style.backgroundColor = 'transparent';
            }
        }
    };

    // No need to change this
    window.onload = function () {
        // Init is called once window has been loaded
        init();
    };
})();