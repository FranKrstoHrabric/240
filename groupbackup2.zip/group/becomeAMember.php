<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php require $meta; ?>
  <link rel="stylesheet" href="./css/style.css">
  <title>SpiRIT | Home</title>
  <?php require $bootstrapScript; ?>
</head>

<body>
  <!--Top photo-->
  <a href="index.php">
    <div class="d-flex justify-content-center align-items-center w-100">
      <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
    </div>
  </a>
  <!--End of Top photo-->

  <?php require $navigation; ?>

  <h1 class="text-center mt-5">Join us today!</h1>
  <h3 class="text-center mt-5">Lorem ipsum dolor sit amet</h3>

  <form class="form-horizontal mt-5" action="/action_page.php">
    <div class="form-group">

      <label class="control-label col-sm-2" for="fName">First Name</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="fName" placeholder="Enter First Name">
      </div>

      <label class="control-label col-sm-2" for="email">Last Name</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="lName" placeholder="Enter Last Name">
      </div>

    </div>

    <div class="form-group">

      <label class="control-label col-sm-2" for="campusAndMajor">Campus and Major</label>
      <div class="col-sm-7">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropDownMajor" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Select
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">1</a>
            <a class="dropdown-item" href="#">2</a>
            <a class="dropdown-item" href="#">3</a>
            <a class="dropdown-item" href="#">4</a>
          </div>
        </div>
      </div>

      <label class="control-label col-sm-2" for="yearLevel">Year Level</label>
      <div class="col-sm-7">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropDownYearLevel" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Select
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">1</a>
            <a class="dropdown-item" href="#">2</a>
            <a class="dropdown-item" href="#">3</a>
            <a class="dropdown-item" href="#">4</a>
          </div>
        </div>
      </div>

    </div>

    <div class="form-group">

      <label class="control-label col-sm-2" for="RITEmail">RIT Email</label>
      <div class="col-sm-6">
        <input type="email" class="form-control" id="RITEmail" placeholder="Enter Email">
      </div>


    </div>

    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-warning">Apply</button>
      </div>
    </div>
  </form>

  <!-- Footer -->
  <footer class="text-center text-lg-start">
    <div class="p-2 footer">
      <p><strong>Copyright 2021 &copy; SpiRIT Club</strong> </p>
    </div>
  </footer>
  <!--End of Footer-->

  <?php require $bootstrapOptional; ?>
</body>

</html>