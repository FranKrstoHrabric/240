<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php require $meta; ?>
    <link rel="stylesheet" href="./css/style.css">
    <title>SpiRIT | Home</title>
    <?php require $bootstrapScript; ?>
</head>

<body>
    <!--Top photo-->
    <a href="index.php">
        <div class="d-flex justify-content-center align-items-center w-100">
            <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
        </div>
    </a>
    <!--End of Top photo-->

    <?php require $navigation; ?>

    <?php require $footer; ?>
    <?php require $bootstrapOptional; ?>
</body>

</html>