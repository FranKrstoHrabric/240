<nav class="navbar navbar-expand-lg sticky-top">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav nav-fill w-100">
            <li class="nav-item">
                <a class="nav-link" href="ourStory.php"><strong>OUR STORY</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="mens.php"><strong>MEN'S</strong></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="womens.php"><strong>WOMEN'S</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="props.php"><strong>SPIRIT PROPS</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="becomeAMember.php"> <strong>BECOME A MEMBER</strong></a>
            </li>
        </ul>
    </div>
</nav>