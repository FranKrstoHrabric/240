<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php require $meta; ?>
    <link rel="stylesheet" href="./css/style.css">
    <title>SpiRIT | Home</title>
    <?php require $bootstrapScript; ?>
</head>

<body>
    <!--Top photo-->
    <a href="index.php">
        <div class="d-flex justify-content-center align-items-center w-100">
            <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
        </div>
    </a>
    <!--End of Top photo-->

    <?php require $navigation; ?>

    <img src="./media/images/people.jpg" alt="img of people" ALIGN="left">
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Temporibus aspernatur, quod voluptatibus, placeat aut itaque incidunt, unde animi quas explicabo earum quo nulla tempore ipsum ut nobis mollitia alias commodi.
        Incidunt nisi eius nam excepturi illo nobis consequuntur provident tenetur. Quibusdam autem illum architecto dignissimos consequuntur quam recusandae obcaecati doloribus deserunt facere consequatur, at dicta, nam perferendis accusamus dolore. Temporibus.
        Dolorem expedita placeat soluta dolorum porro esse cum necessitatibus, nesciunt fuga similique eum ad incidunt fugit, assumenda perferendis cumque deleniti temporibus iste, autem alias asperiores neque cupiditate tempore adipisci? Soluta!
        Hic corrupti debitis ea similique voluptatum, aut possimus facere reiciendis! Perferendis delectus officia beatae ipsum hic quaerat reiciendis sed labore amet ea! Maxime tempora enim officiis saepe vero error facilis.
        Veritatis praesentium, deleniti minus obcaecati atque ipsam! Provident quam adipisci dolor? Eum porro quae, molestias, praesentium, laudantium doloremque hic ea tenetur aut inventore alias excepturi quia possimus eos quaerat non!
        Voluptatum architecto exercitationem culpa quae incidunt expedita hic reiciendis consectetur asperiores. Minus, a ipsam, voluptas commodi tempore illum dolor aliquam, dicta similique quod consectetur! Dicta iusto temporibus earum hic quos.
        Vitae, dolores. Accusantium iste nam veniam dolore illo, maxime optio cum quisquam dignissimos est incidunt ea. Aspernatur et mollitia, ipsum, delectus molestias enim sint quam quos corrupti unde est tenetur!
        Ad fugiat repudiandae, quidem labore adipisci vitae illo inventore doloremque possimus illum cum itaque laudantium minima dolorum error excepturi animi eveniet repellendus. Accusamus nisi nesciunt incidunt dolor sapiente dolorum provident.
        Culpa debitis dolor maiores ipsam, architecto officiis ipsa quam nisi. Repellendus quibusdam aliquid doloremque, et perferendis, eos temporibus quisquam ratione ea officia, sed eius. Tempore accusamus voluptas doloremque pariatur optio.
        Culpa eos eaque reprehenderit incidunt, modi aliquam cumque ea eligendi neque, consequatur ex! Debitis, odiminima corrupti culpa iste blanditiis incidunt voluptatum saepe sit quae veritatis nisi, eos mollitia!
        Veritatis qui nulla itaque, labore ex dolore mollitia earum, dolorum velit enim inventore voluptas provident nihil a maiores, temporibus quo commodi nesciunt quae omnis? Dolorum at cumque perspiciatis sint laborum?
        Saepe illum corporis mollitia iure molestias minus quibusdam sunt veniam, non nesciunt ipsum eos deleniti quo iste praesentium perferendis! Omnis nam consequatur repudiandae assumenda, odit ex. Facilis iste asperiores aliquam!
        Similique corporis maxime cum! Nihil mollitia, delectus minus ratione dolore molestias soluta doloremque qui error ipsum ad earum sunt itaque enim magni aliquam? Fugiat modi nihil eum odit, nulla quaerat!
        Cupiditate hic possimus non doloribus nulla veniam quam officia perferendis accusantium recusandae dicta tenetur nemo quo, porroaecati unde quas? Libero cupiditate nesciunt suscipit cumque optio repudiandae assumenda iste, atque maxime.
        Voluptatibus dignissimos hic voluptas molestiae explicabo sequi porro illum sed ut soluta. Suscipit laboriosam atque accusamus sed deleniti distinctio odio eligendi quam neque possimus voluptate molestiae, rem sunt, corporis expedita.
        Explicabo optio accusamus, assumenda quidem dicta aliquam aperiam est sed accusantium quis! Excepturi, iusto harum. Ex beatae cupiditate debitis ratione consequatur nesciunt temporibus molestias magni nostrum nisi. Exercitationem, modi vel!
        Qui praesentium at aperiam ullam pariatur. Ea laborum magni dolorum aliquid soluta esse quod in, fugit numquam similique cum quas est veniam minima amet? Omnis ratione a inventore autem ab.
        Laboriosam ad corrupti, voluptates exercitationem atque animi dicta numquam porro odit eveniet sapiente mollitia. Sequi, porro deserunt obcaecati culpa mollitia aliquid molestias maiores omnis id provident quibusdam iusto? Maiores, consequuntur.
        Magni eum, illum quo, harum quaerat maxime numquam corporis quia, eligendi dolorum accusantium in commodi impedit praesentium odit quae mollitia error! Tempora obcaecati qui iste at placeat officia vero illum?</p>


    <!-- Footer -->
    <footer class="text-center text-lg-start">
        <div class="p-2 footer">
            <p><strong>Copyright 2021 &copy; SpiRIT Club</strong> </p>
        </div>
    </footer>
    <!--End of Footer-->

    <?php require $bootstrapOptional; ?>
</body>

</html>