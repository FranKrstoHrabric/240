<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php require $meta; ?>
    <link rel="stylesheet" href="./css/style.css">
    <title>SpiRIT | Home</title>
    <?php require $bootstrapScript; ?>
</head>

<body>
    <!--Top photo-->
    <a href="index.php">
        <div class="d-flex justify-content-center align-items-center w-100">
            <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
        </div>
    </a>
    <!--End of Top photo-->

    <?php require $navigation; ?>

    <h1 class="my-5 text-center">The Amazing <b>people behind SpiRIT club</b></h1>
    <div class="d-flex flex-row mb-5">
        <img class="card-img-top w-50 p-6 formula" src="./media/images/about.jpg" alt="#">

        <div class="p-6 w-50">
            <p class=" ml-4 text-justify">RIT SpiRIT club started as the project idea of three freshmen enthusiasts: Fran Krsto Hrabric, Karlo Longin, and Nina Novosel; who were working on their project for Web and Mobile II. The idea for the club was born when they come to the realization that RIT Croatia doesn't have its own merchandise webshop, and products for the main campus in Rochester are difficult to obtain. One additional motive was the fact that the products that Student Government managed to procure were available in very limited quantities, and the interest in the RIT merchandise was really huge among the students.</p>
            <p class=" ml-4 text-justify">Fran, Karlo, and Nina made a webshop, scored an A in the Web and Mobile II, and successfully founded the club in the following fall semester. From its founding until today the SpiRIT Club has significantly increased the number of its members, and today is one of the most successful RIT Croatia clubs, including the members in both (Zagreb and Dubrovnik) campuses.</p>
            <p class=" ml-4 text-justify">If you are an RIT student and you think that you would be the perfect candidate to help us spread the tiger spirit, even more, fill out the application form and let us hear your roar. New members are always welcomed! Also, if you are not a member of the RIT community, but you recognized our work and would like to help, feel free to contact us via email. We will be glad to hear from you.</p>
        </div>
    </div>




    <!-- Footer -->
    <footer class="text-center text-lg-start">
        <div class="p-2 footer">
            <p><strong>Copyright 2021 &copy; SpiRIT Club</strong> </p>
        </div>
    </footer>
    <!--End of Footer-->

    <?php require $bootstrapOptional; ?>
</body>

</html>