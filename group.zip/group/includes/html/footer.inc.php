<!-- Footer -->
<footer class="text-center text-lg-start">
    <div class="p-2 footer">
        <p><strong>Copyright 2021 &copy; SpiRIT Club</strong> </p>
    </div>
</footer>
<!--End of Footer-->