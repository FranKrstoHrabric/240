<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $user = "kl9523"; // SOLACE: RITUSERNAME
  $password = "Direful6&dogs"; // SOLACE: PASSWORD from .my.cnf
  $db = "kl9523"; // SOLACE: RITUSERNAME
  $host = "localhost"; // Always stays the same
  

  function retrieveDatabaseConnection() {
    global $user, $password, $db, $host;

    // For SOLACE remove $port and for MAMP $port is needed
    $mysqli = new mysqli($host, $user, $password, $db);

    if(!$mysqli) {
      $errorMessage = "ERROR {$mysqli->connect_error}";
      exit($errorMessage);
    }

    return $mysqli;
  }

?>