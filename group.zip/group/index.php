<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php require $meta; ?>
    <link rel="stylesheet" href="./css/style.css">
    <title>SpiRIT | Home</title>
    <?php require $bootstrapScript; ?>
</head>

<body>
    <!--Top photo-->
    <a href="index.php">
        <div class="d-flex justify-content-center align-items-center w-100">
            <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
        </div>
    </a>
    <!--End of Top photo-->

    <!-- Navigation -->
    <?php require $navigation; ?>

    <div><h1 class="display-4 text-center welcome p-5 mt-4">WELCOME TO <br> RIT Croatia WEBSHOP!</h1></div>


    <div id="carousel">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" data-interval="2000">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="./media/images/slide01.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="container">
                            <div class="row justify-content-start text-left">
                                <div class="col-lg-8 mx-2">
                                    <p>NEW ESSENTIALS COLLECTION 2021</p>
                                    <h1>Get up to 30% Off</h1>
                                    <h1>New Arrivals</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="./media/images/slide02.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="container">
                            <div class="row justify-content-start text-left">
                                <div class="col-lg-8 mx-2">
                                    <p>ACCESSORIES </p>
                                    <h1>Bags, Hats, Mugs</h1>
                                    <h1>We got You</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="./media/images/slide03.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <div class="container">
                            <div class="row justify-content-start text-left">
                                <div class="col-lg-8 mx-2">
                                    <p>COMFY COLLECTION 2021</p>
                                    <h1>Get up to 50% Off</h1>
                                    <h1>Last chance</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

    <!-- Cards -->
    <section class="sub">
        <div class="container py-5 text-white">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-md-6 col-12">
                    <div class="row">
                        <div class="col-lg-2">
                            <span></span>
                        </div>
                        <div class="col-lg-10">
                            <a>Become a Member of SpiRIT!</a>
                            <a href="becomeAMember.php"><button class="btn btn-success">Apply</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-md-6 col-12">
                    <div class="row">
                        <div class="col-lg-2">
                            <span></span>
                        </div>
                        <div class="col-lg-10">
                            <input type="text" placeholder="Your Email">
                            <button class="btn btn-success">Subscribe</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="text-center mt-5">
        <h1 class="mb-4 webshop w-50 orange"> RIT Webshop</h1>
        <p class="mb-3"><b>This is a student run business!</b></p>
        <p class="mb-3"><b>If you want to join SpiRIT Club <br> contact us at: <br> something@rit.edu</b></p>
        <p><b>Follow us on social media:</b></p>
        <div class="mb-3">  
          <!-- Facebook -->
            <i class="fab fa-facebook-f"></i>

            <!-- Twitter -->
            <i class="fab fa-twitter"></i>

            <!-- Instagram -->
            <i class="fab fa-instagram"></i>
          </div>

    </div>

    <?php require $footer; ?>
    <?php require $bootstrapOptional; ?>
</body>

</html>