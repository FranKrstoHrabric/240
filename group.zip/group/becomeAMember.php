<?php
require "includes/configuration.inc.php";
require "includes/db-configuration.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php require $meta; ?>
  <link rel="stylesheet" href="./css/style.css">
  <title>SpiRIT | Home</title>
  <?php require $bootstrapScript; ?>
</head>

<body>
  <!--Top photo-->
  <a href="index.php">
    <div class="d-flex justify-content-center align-items-center w-100">
      <img src="./media/images/logoSpiRIT.svg" class="headphoto" alt="Logo" />
    </div>
  </a>
  <!--End of Top photo-->

  <?php require $navigation; ?>

  <form class="mt-4 p-4 mx-auto w-100 d-flex flex-column" action="" method="post" name="applyForm"
    onsubmit="return validateForm();">

  <h1 class="text-center mt-5">Join us today!</h1>

  <div class="form-group col-8 mx-auto">
        <label for="fname">First Name</label>
        <input required class="form-control" type="text" id="fname" name="fname" placeholder="Enter first name">
      </div>

      <div class="form-group col-8 mx-auto">
        <label for="lname">Last name</label>
        <input required class="form-control" type="text" id="lname" name="lname" placeholder="Enter last name">
      </div>

      
    <div class="form-group col-8 mx-auto">
      <label for="major">Campus and major</label>
      <select class="form-control" id="major">
        <option>Zagreb - Business Administration: International Business</option>
        <option>Zagreb - IT / Web and Mobile Computing</option>
        <option>Dubrovnik - IT / Web and Mobile Computing</option>
        <option>Dubrovnik - Hospitality and Tourism Management</option>
      </select>
    </div>

    <label for="year" class="col-8 mx-auto">Year level</label>
    <div class="row ml-3 col-8 mx-auto mb-3">
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" checked>
        <label class="form-check-label" for="inlineRadio1">freshman</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
        <label class="form-check-label" for="inlineRadio2">sophomore</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3">
        <label class="form-check-label" for="inlineRadio2">junior</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio4" value="option4">
        <label class="form-check-label" for="inlineRadio2">senior</label>
      </div>
    </div>

      <div class="form-group col-8 mx-auto">
        <label for="email">RIT Email</label>
        <input required class="form-control" type="email" id="email" name="email" placeholder="e.g. jd1234@rit.edu">
      </div>

      <div class="form-group col-8 mx-auto">
      <label for="exampleFormControlTextarea1">Why do you want to apply?</label>
      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Explain in a few sentences"></textarea>
    </div>

      <input class="mt-4 btn btn-primary col-1 mx-auto" type="submit" value="APPLY">
      <div id="errorContainer" class="d-flex flex-column"></div>
    </form>

  <!-- Footer -->
  <footer class="text-center text-lg-start">
    <div class="p-2 footer">
      <p><strong>Copyright 2021 &copy; SpiRIT Club</strong> </p>
    </div>
  </footer>
  <!--End of Footer-->

  <?php require $bootstrapOptional; ?>
</body>

</html>